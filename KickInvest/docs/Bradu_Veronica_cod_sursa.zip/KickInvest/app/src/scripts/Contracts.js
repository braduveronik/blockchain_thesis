const fs = require('fs');

// base class for all contract classes
class ContractBase {
    constructor(ethd, contract) {
        this.ethd = ethd;
        this.contract = contract;
        this.eventListener = {}
    }


    // Registers an event listener with a callback,
    //  and unsubscribes after the first triggered event
    waitForEvent(eventName, cb) {
        let eventListener = this.contract.events[eventName]((err, subscription) => {
            if (!err) {
                cb(err, subscription);
                eventListener.unsubscribe();
            }
        });
    }

    // Registers an event listener for a certain event type, with a callback
    subscribeToEvent(eventName, cb) {
        this.unsubscribeToEvent(eventName);
        this.eventListener[eventName] = this.contract.events[eventName]((err, subscription) => {
            if (!err) {
                cb(err, subscription);
            }
        });
    }

    // Removes the event listener for a certain event type
    unsubscribeToEvent(eventName) {
        if (typeof this.eventListener[eventName] !== 'undefined') {
            this.eventListener[eventName].unsubscribe();
        }
    }

    // Returns the address
    getAddress() {
        return this.contract._address;
    }
}

// Javascript wrapper for the Governor contract
class Governor extends ContractBase {
    async getOwner() {
        return this.contract.methods.owner().call();
    }

    // Returns an account address for a given ETH public address
    getAccount(address = null) {
        if (!address) {
            address = this.ethd.getCurrentAccount();
        }
        return this.contract.methods.getAccount(address).call();
    }

    // Returns all the projects contained by the governor
    async getProjects() {
        return this.contract.methods.getProjects().call();
    }

    // Creates a project
    async createProject(...args) {
        return new Promise((resolve, reject) => {
            this.waitForEvent('NewProject', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                if (subscription.returnValues.creator === this.ethd.getCurrentAccount().address) {
                    resolve(subscription.returnValues.projectAddress);
                }
            });

            try {
                this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.createProject(...args));
            }
            catch (exc) {
                reject(exc);
            }
        });
    }

    // Create an account
    async createAccount(name) {
        return new Promise(async (resolve, reject) => {
            this.waitForEvent('NewAccount', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                if (subscription.returnValues.creator === this.ethd.getCurrentAccount().address) {
                    resolve(subscription.returnValues.accountAddress);
                }
            });

            try {
                await this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.createAccount(name));
            }
            catch (exc) {
                reject(exc);
            }
        });
    }
}

// Javascript wrapper for Account RTH contract
class Account extends ContractBase {
    getName() {
        return this.contract.methods.getName().call();
    }

    // Invest function
    async invest(project, value) {
        return new Promise(async (resolve, reject) => {
            project.waitForEvent('NewInvestor', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                if (subscription.returnValues.investor === this.getAddress()) {
                    resolve(subscription.returnValues.investor);
                }
            });

            try {
                await this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.invest(project.getAddress()), value, 1500000);
            }
            catch (exc) {
                reject(exc);
            }
        });
    }

    // Create project function
    async createProject(...args) {
        return new Promise(async (resolve, reject) => {
            this.waitForEvent('NewProject', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                if (subscription.returnValues.creator === this.contract._address) {
                    resolve(subscription.returnValues.projectAddress);
                }
            });
            try {
                await this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.createProject(...args));
            }
            catch (exc) {
                reject(exc);
            }
        });
    }

    // initialize transfer function
    async initTransfer(project, recipient, reason, value) {
        return new Promise(async (resolve, reject) => {
            project.waitForEvent('NewTransfer', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                resolve(subscription.returnValues.transferAddress);
            });

            try {
                await this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.initTransfer(project.getAddress(), recipient, reason, value));
            }
            catch (exc) {
                reject(exc);
            }
        });
    }

    // Cast a pro vote for a transfer
    async castAye(transfer) {
        return new Promise(async (resolve, reject) => {
            transfer.waitForEvent('NewVote', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                resolve(subscription.returnValues.caster);
            });
            try {
                await this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.voteAye(transfer.getAddress()));
            }
            catch (exc) {
                reject(exc);
            }
        });
    }

    // Cast a con vote for a transfer
    async castNay(transfer) {
        return new Promise(async (resolve, reject) => {
            transfer.waitForEvent('NewVote', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                resolve(subscription.returnValues.caster);
            });
            try {
                await this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.voteNay(transfer.getAddress()));
            }
            catch (exc) {
                reject(exc);
            }
        });
    }

    // Remove a vote from a transfer
    async removeVote(transfer) {
        return new Promise(async (resolve, reject) => {
            transfer.waitForEvent('NewVote', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                resolve(subscription.returnValues.caster);
            });
            try {
                await this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.removeVote(transfer.getAddress()));
            }
            catch (exc) {
                reject(exc);
            }
        });
    }

    // Call checkVotes method from contract
    async checkVotes(transfer) {
        return new Promise(async (resolve, reject) => {
            transfer.waitForEvent('TransferStatus', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                resolve(subscription.returnValues.result);
            });
            try {
                await this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.checkVotes(transfer.getAddress()));
            }
            catch (exc) {
                reject(exc);
            }
        });
    }

    // Remove a transfer
    async removeTransfer(transfer) {
        return new Promise(async (resolve, reject) => {
            transfer.waitForEvent('TransferStatus', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                resolve(subscription.returnValues.result);
            });
            try {
                await this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.removeTransfer(transfer.getAddress()));
            }
            catch (exc) {
                reject(exc);
            }
        });
    }

    // Get all invested projects from a certain account
    getInvestedProjects() {
        return this.contract.methods.getInvestedProjects().call();
    }

    // Get all created projects
    getPersonalProjects() {
        return this.contract.methods.getPersonalProjects().call();
    }

    // Get the invested sum for a given project
    getInvestedSum(address) {
        return this.contract.methods.getInvestedSum(address).call();
    }
}

// Javascript wrapper for Project contract
class Project extends ContractBase {
    getOwner() {
        return this.contract.methods.owner().call();
    }

    getName() {
        return this.contract.methods.name().call();
    }

    getEmail() {
        return this.contract.methods.email().call();
    }

    getDescription() {
        return this.contract.methods.description().call();
    }

    getImg() {
        return this.contract.methods.img().call();
    }

    getNumberOfInvestors() {
        return this.contract.methods.getNumberOfInvestors().call();
    }

    getProjectAccount() {
        return this.contract.methods.account().call();
    }

    getTransfers() {
        return this.contract.methods.getTransfers().call();
    }

    // Invest in this project without a Kickinvest account
    investAnnonymous(value) {
        return new Promise((resolve, reject) => {
            this.waitForEvent('NewInvestor', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                if (subscription.returnValues.creator === this.ethd.getCurrentAccount().address) {
                    resolve(subscription.returnValues.projectAddress);
                }
            });

            try {
                this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.investAnnonymous(), value);
            }
            catch (exc) {
                reject(exc);
            }
        });
    }

    // Initialize a transfer
    initTransfer(recipient, reason, value) {
        return new Promise((resolve, reject) => {
            this.getOwner().then((ownerAddress) => {
                if (this.ethd.getCurrentAccount() !== ownerAddress) {
                    reject("Only owner can call this function.");
                }

                this.waitForEvent('NewTransfer', (err, subscription) => {
                    if (err) {
                        reject(err);
                    }
                    if (subscription.returnValues.investor === this.ethd.getCurrentAccount().address) {
                        resolve(subscription.returnValues.transferAddress);
                    }
                });

                try {
                    this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.initTransfer(recipient, reason, value));
                }
                catch (exc) {
                    reject(exc);
                }
            });
        });
    }
}


// Javascript wrapper for Transfer contract
class Transfer extends ContractBase {
    getOwner() {
        return this.contract.methods.owner().call();
    }

    getProject() {
        return this.contract.methods.project().call();
    }

    getRecipient() {
        return this.contract.methods.recipient().call();
    }

    getValue() {
        return this.contract.methods.value().call();
    }

    getReason() {
        return this.contract.methods.reason().call();
    }

    getVotes(address = null) {
        if (!address) {
            address = this.ethd.getCurrentAccount();
        }
        return this.contract.methods.votes(address).call();
    }

    getAyeVotes() {
        return this.contract.methods.getAyeVotes().call();
    }

    getNayVotes() {
        return this.contract.methods.getNayVotes().call();
    }

    getNumberOfVotes() {
        return this.contract.methods.getNumberOfVotes().call();
    }

    getTransferResult() {
        return this.contract.methods.getTransferResult().call();
    }

    getVote(address) {
        return this.contract.methods.getVote(address).call();
    }

    // Cast a pro vote
    aye() {
        return new Promise((resolve, reject) => {
            this.waitForEvent('NewVote', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                if (subscription.returnValues.caster === this.ethd.getCurrentAccount().address) {
                    resolve(true);
                }
            });

            try {
                this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.aye());
            }
            catch (exc) {
                reject(exc);
            }
        });
    }

    // Cast a con vote
    nay() {
        return new Promise((resolve, reject) => {
            this.waitForEvent('NewVote', (err, subscription) => {
                if (err) {
                    reject(err);
                }
                if (subscription.returnValues.caster === this.ethd.getCurrentAccount().address) {
                    resolve(true);
                }
            });

            try {
                this.ethd.signAndCallMethod(this.getAddress(), this.contract.methods.nay());
            }
            catch (exc) {
                reject(exc);
            }
        });
    }
}

// Factory class for creating javascript contract wrappers
export let EthFactory = {
    ethd: null,
    abi: {
        Governor: null,
        Account: null,
        Project: null,
        Transfer: null
    },

    setDriver: function (ethd) {
        this.ethd = ethd;
    },

    // Set an ABI interface
    setAbi: function (contract, abi) {
        if (this.abi.hasOwnProperty(contract)) {
            this.abi[contract] = abi;
        }
    },

    getContract: function (type, address) {
        return new EthFactory.ethd.w3.eth.Contract(type, address);
    },

    Governor: {
        at: function (address) {
            const projectContract = EthFactory.getContract(EthFactory.abi.Governor, address);
            return new Governor(EthFactory.ethd, projectContract);
        }
    },

    Account: {
        at: function (address) {
            const accountContract = EthFactory.getContract(EthFactory.abi.Account, address);
            return new Account(EthFactory.ethd, accountContract);
        }
    },

    Project: {
        at: function (address) {
            const projectContract = EthFactory.getContract(EthFactory.abi.Project, address);
            return new Project(EthFactory.ethd, projectContract);
        }
    },

    Transfer: {
        at: function (address) {
            const transferContract = EthFactory.getContract(EthFactory.abi.Transfer, address);
            return new Transfer(EthFactory.ethd, transferContract);
        }
    }
};
