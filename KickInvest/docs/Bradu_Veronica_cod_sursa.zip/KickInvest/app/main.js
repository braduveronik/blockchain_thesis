const { app, ipcMain, BrowserWindow } = require("electron");
const path = require("path");

function createWindow() {
  win = new BrowserWindow({
    width: 1080,
    height: 600,
    frame: false,
    webPreferences: {
      nodeIntegration: true,
    },
    backgroundColor: "#E3E5E8",
    minHeight: 600,
    minWidth: 800,
    show: false,
    titleBarStyle: "hidden",
  });

  // Wait until the page is loaded, then show the window
  win.once("ready-to-show", () => {
    win.show();
  });

  // DEBUG: show dev tools
  win.openDevTools();

  // Load dev server where the react app is served
  win.loadURL("http://localhost:3000/");
}

app.on("ready", createWindow);

ipcMain.on('test', (event, ...args) => {
  console.log(...args);
});